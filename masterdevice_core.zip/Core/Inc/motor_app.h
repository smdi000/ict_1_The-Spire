#ifndef __MOTOR_APP_H
#define __MOTOR_APP_H

#include "main.h"
#include "motor_control.h"
#include "imu_parser.h"
#include "cmsis_os.h"


typedef enum
{
    MOTOR_APP_MODE_0_ZERO_TORQUE     = 0,
    MOTOR_APP_MODE_1_FIXED_ASSIST    = 1,
    MOTOR_APP_MODE_2_RESERVED        = 2,
    MOTOR_APP_MODE_3_TRAINING_RESIST = 3,
} MotorAppMode_t;

extern volatile uint8_t g_motor_mode_flag;

typedef struct
{
    uint8_t motor_id;
    MotorAppMode_t mode;

    float assist_torque_nm;
    float resist_torque_nm;

    MOTOR_send tx;
    MOTOR_recv rx;
} MotorApp_t;

typedef struct
{
    MotorAppMode_t    app_mode;
    MOTOR_recv        feedback;
    HAL_StatusTypeDef last_comm_status;
    uint32_t          update_count;
} MotorAppSharedState_t;

/* 上层可改的控制参数 */
typedef struct
{
    MotorAppMode_t mode;
    float assist_torque_nm;
    float resist_torque_nm;
} MotorAppCtrlCfg_t;

/* 定频记录的一帧样本 */
typedef struct
{
    uint32_t          tick_ms;
    MotorAppMode_t    app_mode;
    HAL_StatusTypeDef comm_status;
    uint8_t           valid;      /* 1=这次反馈有效, 0=这次反馈无效/超时 */
    MOTOR_recv        feedback;
    IMU_Data_t        imu;
} MotorSample_t;

/* 100Hz 下 200 点 = 2 秒历史 */
#define MOTOR_HISTORY_LEN 200U

void MotorApp_Init(MotorApp_t *ctx, uint8_t motor_id);
HAL_StatusTypeDef MotorApp_RunOnce(MotorApp_t *ctx, const IMU_Data_t *imu);

void MotorApp_SetModeThreadSafe(MotorAppMode_t mode);
void MotorApp_SetAssistTorqueThreadSafe(float torque_nm);
void MotorApp_SetResistTorqueThreadSafe(float torque_nm);

HAL_StatusTypeDef MotorApp_GetSharedState(MotorAppSharedState_t *out);
HAL_StatusTypeDef MotorApp_GetCtrlCfg(MotorAppCtrlCfg_t *out);

/* 按时间顺序拷出最近 n 帧 */
uint16_t MotorApp_GetHistorySnapshot(MotorSample_t *out, uint16_t max_count);

/* 把之前在 freertos.c 里的定义搬到这里来，因为这是公共结构 */
#define SD_BUFFER_SIZE  100

typedef struct {
    MotorSample_t samples[SD_BUFFER_SIZE];
    uint16_t count;
    uint8_t ready_to_write;
} SDBuffer_t;

/* 使用 extern 告诉编译器：这些变量在别的 .c 文件里，这里只是引用 */
extern SDBuffer_t *sd_buf;
extern uint8_t current_write_buf_idx;
extern osSemaphoreId_t SDSemaphoreHandle;

/* 顺便把函数声明也加上，规范一些 */
void MotorApp_SaveToSDBuffer(const MotorApp_t *ctx, const IMU_Data_t *imu, HAL_StatusTypeDef comm_status);

#endif /* 原来的 #endif */
