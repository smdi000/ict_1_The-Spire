#ifndef IMU_PARSER_H
#define IMU_PARSER_H

#include <stdint.h>

// IMU 最终解析出来的数据结构体
typedef struct {
    float accel_x;
    float accel_y;
    float accel_z;
    float roll;
    float pitch;
    float yaw;
} IMU_Data_t;

// 供外部文件（如控制任务）读取的全局变量
extern IMU_Data_t g_imu_data;

// FreeRTOS 中 IMU 任务的入口函数
void IMU_Task_Entry(void);

#endif /* IMU_PARSER_H */