#include "imu_parser.h"
#include "usart.h"       // 包含 huart1
#include "cmsis_os.h"    // FreeRTOS V2 API
#include "FreeRTOS.h"
#include "task.h"
#include <string.h>      // 提供 memcpy

// 引入我们在 CubeMX 里创建的互斥锁句柄
extern osMutexId_t ImuDataMutexHandle;

// --- 配置区 ---
#define RX_BUFFER_SIZE 512
#define FRAME_MAX_LEN  64

// --- 全局变量与底层缓冲 ---
// 【关键】使用 GCC 属性强制 32 字节对齐，防止 M7 内核 D-Cache 污染
uint8_t rx_dma_buffer[RX_BUFFER_SIZE] __attribute__((aligned(32))); 
uint16_t rx_read_ptr = 0;

IMU_Data_t g_imu_data = {0};

// 解析器状态枚举
typedef enum {
    STATE_HEAD1,
    STATE_HEAD2,
    STATE_LEN,
    STATE_PAYLOAD
} ParserState_t;

// --- 内部静态函数前置声明 (解决未声明报错) ---
static void IMU_ParseByte(uint8_t byte);
static void IMU_DecodeFrame(uint8_t* frame, uint8_t len);

// --- FreeRTOS 任务主逻辑 ---
void IMU_Task_Entry(void) {
    // 1. 启动带有 IDLE（空闲）和半满/全满检测的 DMA 循环接收
		HAL_StatusTypeDef ret;
		ret = HAL_UARTEx_ReceiveToIdle_DMA(&huart1, rx_dma_buffer, RX_BUFFER_SIZE);
		if (ret != HAL_OK)
		{
				Error_Handler();
		}    
    // 2. 核心阻塞任务循环
    while (1) {
        // 阻塞休眠，等待串口空闲中断或 DMA 传输中断发来的任务通知
        // pdTRUE: 收到后清零通知值; portMAX_DELAY: 死等，不消耗 CPU
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        // --- 醒来后说明有新数据流入 ---

        // 1. 获取当前 DMA 写入到了哪个位置
        uint16_t rx_write_ptr = RX_BUFFER_SIZE - __HAL_DMA_GET_COUNTER(huart1.hdmarx);
        
        // 2. 【关键】清除 D-Cache，强制 CPU 去物理 RAM 重新读取最新数据
        SCB_InvalidateDCache_by_Addr((uint32_t*)rx_dma_buffer, RX_BUFFER_SIZE);

        // 3. 读指针追赶写指针，将新接收到的字节送入状态机解析
        while (rx_read_ptr != rx_write_ptr) {
            IMU_ParseByte(rx_dma_buffer[rx_read_ptr]);
            
            rx_read_ptr++;
            if (rx_read_ptr >= RX_BUFFER_SIZE) {
                rx_read_ptr = 0; // 环形队列回卷
            }
        }
    }
}

// --- 状态机：逐字节处理，防粘包/断帧 ---
static void IMU_ParseByte(uint8_t byte) {
    static ParserState_t state = STATE_HEAD1;
    static uint8_t frame_buf[FRAME_MAX_LEN];
    static uint8_t frame_idx = 0;
    static uint8_t expected_len = 0;

    switch (state) {
        case STATE_HEAD1:
            if (byte == 0x7E) {
                frame_buf[0] = byte;
                state = STATE_HEAD2;
            }
            break;

        case STATE_HEAD2:
            if (byte == 0x23) {
                frame_buf[1] = byte;
                state = STATE_LEN;
            } else if (byte == 0x7E) {
                // 容错：可能连续收到多个 7E
            } else {
                state = STATE_HEAD1;
            }
            break;

        case STATE_LEN:
            expected_len = byte;
            frame_buf[2] = byte;
            // 合法性校验：长度不能超限，也不能太短 (头2+长1+功能1+校验1 = 5)
            if (expected_len >= 5 && expected_len <= FRAME_MAX_LEN) {
                frame_idx = 3;
                state = STATE_PAYLOAD;
            } else {
                state = STATE_HEAD1;
            }
            break;

        case STATE_PAYLOAD:
            frame_buf[frame_idx++] = byte;
            if (frame_idx == expected_len) {
                // 接收满一帧，触发解码
                IMU_DecodeFrame(frame_buf, expected_len);
                state = STATE_HEAD1; 
            }
            break;
    }
}

// --- 数据解码核心（带互斥锁保护） ---
static void IMU_DecodeFrame(uint8_t* frame, uint8_t len) {
    // 1. 和校验计算
    uint8_t calc_sum = 0;
    for (int i = 0; i < len - 1; i++) {
        calc_sum += frame[i];
    }
    
    if (calc_sum != frame[len - 1]) {
        return; // 校验失败，直接丢弃该脏帧
    }

    // 2. 提取功能字和数据
    uint8_t func = frame[3];
    uint8_t* data = &frame[4];

    if (func == 0x04) { // 加速度
        // 【第一步：在局部变量中完成内存拷贝和浮点计算，不占锁的时间】
        int16_t raw_ax, raw_ay, raw_az;
        memcpy(&raw_ax, &data[0], 2);
        memcpy(&raw_ay, &data[2], 2);
        memcpy(&raw_az, &data[4], 2);

        float factor = 16.0f / 32767.0f;
        float calc_ax = raw_ax * factor;
        float calc_ay = raw_ay * factor;
        float calc_az = raw_az * factor;

        // 【第二步：极速上锁、赋值、解锁】
        // osWaitForever 表示死等，但因为赋值极快，实际上几乎不会阻塞
        if (osMutexAcquire(ImuDataMutexHandle, osWaitForever) == osOK) {
            g_imu_data.accel_x = calc_ax;
            g_imu_data.accel_y = calc_ay;
            g_imu_data.accel_z = calc_az;
            osMutexRelease(ImuDataMutexHandle);
        }

    } 
    else if (func == 0x26) { // 欧拉角
        // 【第一步：局部变量计算】
        float roll, pitch, yaw;
        memcpy(&roll,  &data[0], 4);
        memcpy(&pitch, &data[4], 4);
        memcpy(&yaw,   &data[8], 4);

        float calc_roll  = roll * 57.296f;
        float calc_pitch = pitch * 57.296f;
        float calc_yaw   = yaw * 57.296f;

        // 【第二步：极速上锁、赋值、解锁】
        if (osMutexAcquire(ImuDataMutexHandle, osWaitForever) == osOK) {
            g_imu_data.roll  = calc_roll;
            g_imu_data.pitch = calc_pitch;
            g_imu_data.yaw   = calc_yaw;
            osMutexRelease(ImuDataMutexHandle);
        }
    }
}