#include "motor_app.h"
#include "cmsis_os.h"
#include <string.h>

extern osMutexId_t MotorStateMutexHandle;

volatile uint8_t g_motor_mode_flag = MOTOR_APP_MODE_0_ZERO_TORQUE;

static MotorAppSharedState_t g_motor_shared_state = {0};
static MotorAppCtrlCfg_t     g_motor_ctrl = {
    .mode = MOTOR_APP_MODE_0_ZERO_TORQUE,
    .assist_torque_nm = 0.5f,
    .resist_torque_nm = 0.5f,
};

static MotorSample_t g_motor_history[MOTOR_HISTORY_LEN];
static uint16_t g_motor_hist_write = 0;
static uint16_t g_motor_hist_count = 0;

#define MOTOR_PROTO_STATUS_FOC   1U

static void MotorApp_FillBaseCmd(MotorApp_t *ctx)
{
    memset(&ctx->tx, 0, sizeof(ctx->tx));
    memset(&ctx->rx, 0, sizeof(ctx->rx));

    ctx->tx.id   = ctx->motor_id;
    ctx->tx.mode = MOTOR_PROTO_STATUS_FOC;

    ctx->tx.Pos = 0.0f;
    ctx->tx.W   = 0.0f;
    ctx->tx.K_P = 0.0f;
    ctx->tx.K_W = 0.0f;
    ctx->tx.T   = 0.0f;
}

static float Motor_Mode0_ZeroTorqueLogic(const IMU_Data_t *imu)
{
    (void)imu;
    return 0.0f;
}

static float Motor_Mode1_AssistLogic(MotorApp_t *ctx, const IMU_Data_t *imu)
{
    (void)imu;
    return ctx->assist_torque_nm;
}

static float Motor_Mode3_ResistLogic(MotorApp_t *ctx, const IMU_Data_t *imu)
{
    (void)imu;
    return -ctx->resist_torque_nm;
}

HAL_StatusTypeDef MotorApp_GetCtrlCfg(MotorAppCtrlCfg_t *out)
{
    if (out == NULL) return HAL_ERROR;

    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        *out = g_motor_ctrl;
        osMutexRelease(MotorStateMutexHandle);
        return HAL_OK;
    }

    return HAL_ERROR;
}

static void MotorApp_UpdateSharedState(const MotorApp_t *ctx, HAL_StatusTypeDef comm_status)
{
    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        g_motor_shared_state.app_mode = ctx->mode;
        g_motor_shared_state.last_comm_status = comm_status;

        if ((comm_status == HAL_OK) && (ctx->rx.correct == 1))
        {
            g_motor_shared_state.feedback = ctx->rx;
            g_motor_shared_state.update_count++;
        }

        osMutexRelease(MotorStateMutexHandle);
    }
}

static void MotorApp_PushHistory(const MotorApp_t *ctx,
                                 const IMU_Data_t *imu,
                                 HAL_StatusTypeDef comm_status)
{
    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        MotorSample_t *slot = &g_motor_history[g_motor_hist_write];
        memset(slot, 0, sizeof(*slot));

        slot->tick_ms = osKernelGetTickCount();
        slot->app_mode = ctx->mode;
        slot->comm_status = comm_status;
        slot->valid = ((comm_status == HAL_OK) && (ctx->rx.correct == 1)) ? 1U : 0U;

        if (imu != NULL)
        {
            slot->imu = *imu;
        }

        if (slot->valid)
        {
            slot->feedback = ctx->rx;
        }

        g_motor_hist_write++;
        if (g_motor_hist_write >= MOTOR_HISTORY_LEN)
        {
            g_motor_hist_write = 0;
        }

        if (g_motor_hist_count < MOTOR_HISTORY_LEN)
        {
            g_motor_hist_count++;
        }

        osMutexRelease(MotorStateMutexHandle);
    }
}

uint16_t MotorApp_GetHistorySnapshot(MotorSample_t *out, uint16_t max_count)
{
    uint16_t n = 0;

    if ((out == NULL) || (max_count == 0U))
    {
        return 0U;
    }

    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        n = (g_motor_hist_count < max_count) ? g_motor_hist_count : max_count;

        uint16_t start =
            (uint16_t)((g_motor_hist_write + MOTOR_HISTORY_LEN - n) % MOTOR_HISTORY_LEN);

        for (uint16_t i = 0; i < n; i++)
        {
            out[i] = g_motor_history[(start + i) % MOTOR_HISTORY_LEN];
        }

        osMutexRelease(MotorStateMutexHandle);
    }

    return n;
}

void MotorApp_SetModeThreadSafe(MotorAppMode_t mode)
{
    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        g_motor_mode_flag = (uint8_t)mode;
        g_motor_ctrl.mode = mode;
        g_motor_shared_state.app_mode = mode;
        osMutexRelease(MotorStateMutexHandle);
    }
}

void MotorApp_SetAssistTorqueThreadSafe(float torque_nm)
{
    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        g_motor_ctrl.assist_torque_nm = torque_nm;
        osMutexRelease(MotorStateMutexHandle);
    }
}

void MotorApp_SetResistTorqueThreadSafe(float torque_nm)
{
    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        g_motor_ctrl.resist_torque_nm = torque_nm;
        osMutexRelease(MotorStateMutexHandle);
    }
}

HAL_StatusTypeDef MotorApp_GetSharedState(MotorAppSharedState_t *out)
{
    if (out == NULL) return HAL_ERROR;

    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        *out = g_motor_shared_state;
        osMutexRelease(MotorStateMutexHandle);
        return HAL_OK;
    }

    return HAL_ERROR;
}

void MotorApp_Init(MotorApp_t *ctx, uint8_t motor_id)
{
    memset(ctx, 0, sizeof(*ctx));
    ctx->motor_id = motor_id;

    if (osMutexAcquire(MotorStateMutexHandle, osWaitForever) == osOK)
    {
        g_motor_mode_flag = MOTOR_APP_MODE_0_ZERO_TORQUE;

        memset(&g_motor_shared_state, 0, sizeof(g_motor_shared_state));
        g_motor_shared_state.app_mode = MOTOR_APP_MODE_0_ZERO_TORQUE;

        g_motor_ctrl.mode = MOTOR_APP_MODE_0_ZERO_TORQUE;
        g_motor_ctrl.assist_torque_nm = 0.5f;
        g_motor_ctrl.resist_torque_nm = 0.5f;

        memset(g_motor_history, 0, sizeof(g_motor_history));
        g_motor_hist_write = 0;
        g_motor_hist_count = 0;

        osMutexRelease(MotorStateMutexHandle);
    }
}

HAL_StatusTypeDef MotorApp_RunOnce(MotorApp_t *ctx, const IMU_Data_t *imu)
{
    MotorAppCtrlCfg_t cfg = {0};

    if (MotorApp_GetCtrlCfg(&cfg) != HAL_OK)
    {
        return HAL_ERROR;
    }

    ctx->mode = cfg.mode;
    ctx->assist_torque_nm = cfg.assist_torque_nm;
    ctx->resist_torque_nm = cfg.resist_torque_nm;

    MotorApp_FillBaseCmd(ctx);

    switch (ctx->mode)
    {
        case MOTOR_APP_MODE_0_ZERO_TORQUE:
            ctx->tx.T = Motor_Mode0_ZeroTorqueLogic(imu);
            break;

        case MOTOR_APP_MODE_1_FIXED_ASSIST:
            ctx->tx.T = Motor_Mode1_AssistLogic(ctx, imu);
            break;

        case MOTOR_APP_MODE_3_TRAINING_RESIST:
            ctx->tx.T = Motor_Mode3_ResistLogic(ctx, imu);
            break;

        case MOTOR_APP_MODE_2_RESERVED:
        default:
            ctx->tx.T = 0.0f;
            break;
    }

    HAL_StatusTypeDef ret = SERVO_Send_recv(&ctx->tx, &ctx->rx);

    MotorApp_UpdateSharedState(ctx, ret);
    MotorApp_PushHistory(ctx, imu, ret);


    // ��������һ�䡿��ÿ������������㷨���Ͱ���֡�����ӽ� SD �����ݴ�����
    MotorApp_SaveToSDBuffer(ctx, imu, ret); 

    return ret;
}
// �������������ÿ�� MotorApp_RunOnce �󱻵���
void MotorApp_SaveToSDBuffer(const MotorApp_t *ctx, const IMU_Data_t *imu, HAL_StatusTypeDef comm_status)
{
    SDBuffer_t *active_buf = &sd_buf[current_write_buf_idx];
    
    // ���һ֡����
    MotorSample_t *slot = &active_buf->samples[active_buf->count];
    slot->tick_ms = osKernelGetTickCount();
    slot->app_mode = ctx->mode;
    slot->comm_status = comm_status;
    slot->valid = ((comm_status == HAL_OK) && (ctx->rx.correct == 1)) ? 1U : 0U;
    
    if (imu != NULL) slot->imu = *imu;
    if (slot->valid) slot->feedback = ctx->rx;

    active_buf->count++;

    // ������������ˣ������л������� SD ����
    if (active_buf->count >= SD_BUFFER_SIZE) {
        active_buf->ready_to_write = 1;
        
        // ƹ���л��������� 0 �� 1 ֮�䷭ת
        current_write_buf_idx = 1 - current_write_buf_idx;
        sd_buf[current_write_buf_idx].count = 0; 
        sd_buf[current_write_buf_idx].ready_to_write = 0;

        // �����ź��������� SDTask ȥ����
        if (SDSemaphoreHandle != NULL) {
            osSemaphoreRelease(SDSemaphoreHandle);
        }
    }
}