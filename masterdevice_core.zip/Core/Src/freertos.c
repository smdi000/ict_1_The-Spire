/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "imu_parser.h"
#include "motor_control.h"
#include "motor_app.h"
#include "fatfs.h"
#include "stdio.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */


static char format_buf[256]; // 文本转换缓冲，放在全局避免爆栈

// 强制将双缓冲区的地址映射到 0x30000000 (D2 SRAM的起始位置)
#define SD_BUF_BASE_ADDR 0x30000000
SDBuffer_t *sd_buf = (SDBuffer_t *)SD_BUF_BASE_ADDR; 

uint8_t current_write_buf_idx = 0; // 当前控制任务正在写入的缓冲区索引 (0 或 1)

// 用于唤醒 SD 任务的二值信号量 (需要在 MX_FREERTOS_Init 中创建它)
osSemaphoreId_t SDSemaphoreHandle; 
const osSemaphoreAttr_t SDSemaphore_attributes = {
  .name = "SDSemaphore"
};
/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for IMUTask */
osThreadId_t IMUTaskHandle;
const osThreadAttr_t IMUTask_attributes = {
  .name = "IMUTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal1,
};
/* Definitions for MotorTask */
osThreadId_t MotorTaskHandle;
const osThreadAttr_t MotorTask_attributes = {
  .name = "MotorTask",
  .stack_size = 768 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for SDTask */
osThreadId_t SDTaskHandle;
const osThreadAttr_t SDTask_attributes = {
  .name = "SDTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal4,
};
/* Definitions for ImuDataMutex */
osMutexId_t ImuDataMutexHandle;
const osMutexAttr_t ImuDataMutex_attributes = {
  .name = "ImuDataMutex"
};
/* Definitions for MotorStateMutex */
osMutexId_t MotorStateMutexHandle;
const osMutexAttr_t MotorStateMutex_attributes = {
  .name = "MotorStateMutex"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void StartIMUTask(void *argument);
void StartMotorTask(void *argument);
void StartSDTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */
  /* Create the mutex(es) */
  /* creation of ImuDataMutex */
  ImuDataMutexHandle = osMutexNew(&ImuDataMutex_attributes);

  /* creation of MotorStateMutex */
  MotorStateMutexHandle = osMutexNew(&MotorStateMutex_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of IMUTask */
  IMUTaskHandle = osThreadNew(StartIMUTask, NULL, &IMUTask_attributes);

  /* creation of MotorTask */
  MotorTaskHandle = osThreadNew(StartMotorTask, NULL, &MotorTask_attributes);

  /* creation of SDTask */
  SDTaskHandle = osThreadNew(StartSDTask, NULL, &SDTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
	
	
	 IMU_Data_t current_pose = {0};
    MotorAppSharedState_t motor_state = {0};

    uint32_t tick_wake = osKernelGetTickCount();
    const uint32_t CONTROL_PERIOD_MS = 10;

    /* 上电默认模式0 */
    MotorApp_SetModeThreadSafe(MOTOR_APP_MODE_0_ZERO_TORQUE);

    /* 以后如果要从 defaultTask 调整力矩参数，就用线程安全接口 */
    MotorApp_SetAssistTorqueThreadSafe(0.5f);
    MotorApp_SetResistTorqueThreadSafe(0.5f);

		
		
  /* Infinite loop */
  for(;;)
  {
     osDelayUntil(tick_wake + CONTROL_PERIOD_MS);
        tick_wake += CONTROL_PERIOD_MS;

        if (osMutexAcquire(ImuDataMutexHandle, 2) == osOK)
        {
            current_pose = g_imu_data;
            osMutexRelease(ImuDataMutexHandle);
        }

        /* 这里先留你的模式切换接口，后面把逻辑填进来 */
        /*
        if (条件A) {
            MotorApp_SetModeThreadSafe(MOTOR_APP_MODE_1_FIXED_ASSIST);
        } else if (条件B) {
            MotorApp_SetModeThreadSafe(MOTOR_APP_MODE_3_TRAINING_RESIST);
        } else {
            MotorApp_SetModeThreadSafe(MOTOR_APP_MODE_0_ZERO_TORQUE);
        }
        */

        /* 如需读最新电机状态 */
        (void)MotorApp_GetSharedState(&motor_state);

        /* 这里可以直接访问：
           motor_state.feedback.T
           motor_state.feedback.W
           motor_state.feedback.Pos
           motor_state.feedback.Temp
           motor_state.feedback.MError
           motor_state.feedback.footForce
        */
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartIMUTask */
/**
* @brief Function implementing the IMUTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartIMUTask */
void StartIMUTask(void *argument)
{
  /* USER CODE BEGIN StartIMUTask */
	IMU_Task_Entry();
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartIMUTask */
}

/* USER CODE BEGIN Header_StartMotorTask */
/**
* @brief Function implementing the MotorTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartMotorTask */
void StartMotorTask(void *argument)
{
  /* USER CODE BEGIN StartMotorTask */
	  MotorApp_t motor;
    IMU_Data_t imu_snapshot = {0};

    uint32_t tick_wake = osKernelGetTickCount();
    const uint32_t MOTOR_PERIOD_MS = 10;

    MotorApp_Init(&motor, 1);
	
		
  /* Infinite loop */
  for(;;)
  {
    osDelayUntil(tick_wake + MOTOR_PERIOD_MS);
        tick_wake += MOTOR_PERIOD_MS;

        if (osMutexAcquire(ImuDataMutexHandle, 1) == osOK)
        {
            imu_snapshot = g_imu_data;
            osMutexRelease(ImuDataMutexHandle);
        }

        (void)MotorApp_RunOnce(&motor, &imu_snapshot);
  }
  /* USER CODE END StartMotorTask */
}

/* USER CODE BEGIN Header_StartSDTask */
/**
* @brief Function implementing the SDTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartSDTask */
void StartSDTask(void *argument)
{
  /* USER CODE BEGIN StartSDTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartSDTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

