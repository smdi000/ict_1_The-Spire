# test_model.py
import numpy as np
import mindspore as ms
from mindspore import Tensor
from ultra_net import InceptionBlock1D, InceptionBackbone, UniversalExoNet

# 设置日志级别（减少无关输出）
ms.set_context(mode=ms.PYNATIVE_MODE)  # 使用 PyNative 模式便于调试


def test_inception_block():
    print("🔍 Testing InceptionBlock1D...")
    B, C, T = 2, 64, 50
    x = Tensor(np.random.randn(B, C, T).astype(np.float32))  # 注意：Conv1d 输入是 (B, C, T)

    block = InceptionBlock1D(
        in_channels=64,
        out_1x1=32, red_3x3=48, out_3x3=64,
        red_5x5=16, out_5x5=32, out_pool=32
    )
    out = block(x)
    expected_channels = 32 + 64 + 32 + 32  # 160
    assert out.shape == (B, expected_channels, T), f"Expected {(B, expected_channels, T)}, got {out.shape}"
    print(f"✅ InceptionBlock1D: input {x.shape} → output {out.shape}\n")


def test_inception_backbone():
    print("🔍 Testing InceptionBackbone...")
    B, T, C = 2, 50, 39
    x = Tensor(np.random.randn(B, T, C).astype(np.float32))  # 模型期望 (B, T, C)

    backbone = InceptionBackbone(input_channels=C, seq_len=T, hidden_dim=256)
    feat = backbone(x)
    assert feat.shape == (B, 256), f"Expected {(B, 256)}, got {feat.shape}"
    print(f"✅ InceptionBackbone: input {x.shape} → feature {feat.shape}\n")


def test_universal_exo_net():
    print("🔍 Testing UniversalExoNet (full model)...")
    B, T, C = 2, 50, 39
    x = Tensor(np.random.randn(B, T, C).astype(np.float32))

    model = UniversalExoNet(
        input_channels=C,
        seq_len=T,
        num_intents=5,
        traj_dim=72,
        hidden_dim=256
    )
    cls_out, traj_out = model(x)
    assert cls_out.shape == (B, 5), f"Classification head error: {cls_out.shape}"
    assert traj_out.shape == (B, 72), f"Trajectory head error: {traj_out.shape}"
    print(f"✅ UniversalExoNet: input {x.shape}")
    print(f"   → Classification: {cls_out.shape}")
    print(f"   → Trajectory:     {traj_out.shape}\n")


def test_gradient_flow():
    print("🔍 Testing gradient flow (backward pass)...")
    B, T, C = 2, 50, 39
    x = Tensor(np.random.randn(B, T, C).astype(np.float32))
    y_cls = Tensor(np.random.randint(0, 5, (B,)).astype(np.int32))
    y_traj = Tensor(np.random.randn(B, 72).astype(np.float32))

    model = UniversalExoNet(input_channels=C, seq_len=T, num_intents=5, traj_dim=72)
    model.set_train()

    def forward_fn(data, label_cls, label_traj):
        logits, traj_pred = model(data)
        loss_cls = ms.nn.CrossEntropyLoss()(logits, label_cls)
        loss_traj = ms.nn.MSELoss()(traj_pred, label_traj)
        return loss_cls + 0.1 * loss_traj

    grad_fn = ms.value_and_grad(forward_fn, None, model.trainable_params())
    loss, grads = grad_fn(x, y_cls, y_traj)

    # 检查梯度是否非零（至少有一个参数有梯度）
    grad_norms = [ms.ops.norm(g) for g in grads if g is not None]
    assert any(norm.asnumpy() > 1e-6 for norm in grad_norms), "All gradients are zero!"
    print(f"✅ Backward pass successful! Total loss: {loss.asnumpy():.4f}\n")


if __name__ == "__main__":
    print("🧪 Starting module-wise unit tests for UltraNet...\n")

    try:
        test_inception_block()
        test_inception_backbone()
        test_universal_exo_net()
        test_gradient_flow()

        print("🎉 All tests passed! Your model is ready for training.")
    except Exception as e:
        print(f"❌ Test failed: {e}")
        raise