# utils/dataset.py
import os
import numpy as np
from mindspore.dataset import GeneratorDataset

class UltraMocapDataset:
    def __init__(self, data_path, load_traj=True, traj_stats_path=None):
        self.data_path = data_path
        self.load_traj = load_traj
        self.traj_stats_path = traj_stats_path  # 新增：标准化参数路径
        self._load_data()
    
    def _load_data(self):
        if not os.path.exists(self.data_path):
            raise FileNotFoundError(f"Data file not found: {self.data_path}")

        data = np.load(self.data_path)

        # 加载原始数据
        x_raw = data['X'].astype(np.float32)   # Shape: (N, 39, 50)
        self.y_cls = data['Y_cls'].astype(np.int32)

        # 🔁 转置：从 (N, 39, 50) → (N, 50, 39)
        if x_raw.ndim == 3 and x_raw.shape[1] == 39 and x_raw.shape[2] == 50:
            self.x = np.transpose(x_raw, (0, 2, 1))  # (N, 50, 39)
            print(f"[Dataset] ⚙️  Transposed X: (N,39,50) → (N,50,39)")
        else:
            self.x = x_raw  # 如果已经是 (N,50,39)，直接使用
            print(f"[Dataset] 📥 Using X as-is: shape={x_raw.shape}")

        # 轨迹标签（如果有）
        if self.load_traj:
            if 'Y_traj' not in data.files:
                raise KeyError("Y_traj not found in .npz file!")
            self.y_traj = data['Y_traj'].astype(np.float32)
            
            # 👇 新增：加载标准化参数（仅训练/验证时使用）
            if self.traj_stats_path is not None:
                if not os.path.exists(self.traj_stats_path):
                    raise FileNotFoundError(f"Trajectory stats file not found: {self.traj_stats_path}")
                stats = np.load(self.traj_stats_path)
                self.traj_mean = stats['mean'].astype(np.float32)  # (72,)
                self.traj_std = stats['std'].astype(np.float32)    # (72,)
                print(f"[Dataset] 📊 Loaded trajectory normalization stats from {self.traj_stats_path}")
            else:
                self.traj_mean = None
                self.traj_std = None
        else:
            self.y_traj = None
            self.traj_mean = None
            self.traj_std = None

        print(f"[Dataset] ✅ Loaded {len(self)} samples")
        print(f"  X shape: {self.x.shape}")
        print(f"  Y_cls shape: {self.y_cls.shape}")
        if self.y_traj is not None:
            print(f"  Y_traj shape: {self.y_traj.shape}")

    def __getitem__(self, index):
        x = self.x[index]
        y_cls = self.y_cls[index]
        if self.y_traj is not None:
            y_traj = self.y_traj[index]
            # 👇 关键：在这里做标准化！
            if self.traj_mean is not None and self.traj_std is not None:
                y_traj = (y_traj - self.traj_mean) / self.traj_std
            return x, y_cls, y_traj
        else:
            return x, y_cls
    
    def __len__(self):
        return len(self.x)


def create_ultra_dataset(
    data_path,              # 👈 关键：传入完整文件路径
    batch_size=32,
    shuffle=True,
    num_parallel_workers=1,
    load_traj=True
):
    # 👇 自动使用 ./data/traj_stats.npz（如果存在且需要轨迹）
    traj_stats_path = "./data/traj_stats.npz" if load_traj else None
    
    dataset_source = UltraMocapDataset(
        data_path, 
        load_traj=load_traj,
        traj_stats_path=traj_stats_path
    )
    
    column_names = ["x", "y_cls", "y_traj"] if load_traj else ["x", "y_cls"]
    
    dataset = GeneratorDataset(
        source=dataset_source,
        column_names=column_names,
        shuffle=shuffle,
        num_parallel_workers=num_parallel_workers,
        python_multiprocessing=False  # 👈 👈 👈 关键修复！
    )
    dataset = dataset.batch(batch_size, drop_remainder=False)
    return dataset