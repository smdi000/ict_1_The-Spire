# model.py
import mindspore.nn as nn
import mindspore.ops as ops
from mindspore import Tensor

class InceptionBlock1D(nn.Cell):
    """1D Inception Block for time-series (EMG/IMU)"""
    def __init__(self, in_channels, out_1x1, red_3x3, out_3x3, red_5x5, out_5x5, out_pool):
        super(InceptionBlock1D, self).__init__()
        # Branch 1: 1x1 conv
        self.branch1 = nn.SequentialCell([
            nn.Conv1d(in_channels, out_1x1, kernel_size=1),
            nn.BatchNorm1d(out_1x1),
            nn.ReLU()
        ])
        # Branch 2: 1x1 -> 3x3
        self.branch2 = nn.SequentialCell([
            nn.Conv1d(in_channels, red_3x3, kernel_size=1),
            nn.BatchNorm1d(red_3x3),
            nn.ReLU(),
            nn.Conv1d(red_3x3, out_3x3, kernel_size=3, pad_mode='pad', padding=1),
            nn.BatchNorm1d(out_3x3),
            nn.ReLU()
        ])
        # Branch 3: 1x1 -> 5x5
        self.branch3 = nn.SequentialCell([
            nn.Conv1d(in_channels, red_5x5, kernel_size=1),
            nn.BatchNorm1d(red_5x5),
            nn.ReLU(),
            nn.Conv1d(red_5x5, out_5x5, kernel_size=5, pad_mode='pad', padding=2),
            nn.BatchNorm1d(out_5x5),
            nn.ReLU()
        ])
        # Branch 4: MaxPool -> 1x1
        self.branch4 = nn.SequentialCell([
            nn.MaxPool1d(kernel_size=3, stride=1, pad_mode='pad', padding=1),
            nn.Conv1d(in_channels, out_pool, kernel_size=1),
            nn.BatchNorm1d(out_pool),
            nn.ReLU()
        ])

    def construct(self, x):
        # x: (B, C, T)
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)
        return ops.concat((b1, b2, b3, b4), axis=1)


class InceptionBackbone(nn.Cell):
    """通用时序特征提取骨干网络"""
    def __init__(self, input_channels=39, seq_len=50, hidden_dim=256):
        super(InceptionBackbone, self).__init__()
        self.input_channels = input_channels
        
        # 初始卷积层（可选）
        self.stem = nn.SequentialCell([
            nn.Conv1d(input_channels, 64, kernel_size=3, pad_mode='pad', padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU()
        ])
        
        # 堆叠 Inception 模块
        self.inception1 = InceptionBlock1D(
            in_channels=64,
            out_1x1=32, red_3x3=48, out_3x3=64,
            red_5x5=16, out_5x5=32, out_pool=32
        )  # output channels: 32+64+32+32 = 160
        
        self.pool1 = nn.MaxPool1d(kernel_size=2, stride=2)  # T: 50 -> 25
        
        self.inception2 = InceptionBlock1D(
            in_channels=160,
            out_1x1=64, red_3x3=96, out_3x3=128,
            red_5x5=32, out_5x5=64, out_pool=64
        )  # output: 64+128+64+64 = 320
        
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        self.flatten = nn.Flatten()
        self.fc = nn.Dense(320, hidden_dim)
        self.relu = nn.ReLU()

    def construct(self, x):
        # x: (B, T, C) → need (B, C, T)
        x = ops.transpose(x, (0, 2, 1))  # (B, T, C) -> (B, C, T)
        x = self.stem(x)
        x = self.inception1(x)
        x = self.pool1(x)
        x = self.inception2(x)
        x = self.global_pool(x)  # (B, 320, 1)
        x = self.flatten(x)      # (B, 320)
        x = self.fc(x)           # (B, hidden_dim)
        return self.relu(x)


class UniversalExoNet(nn.Cell):
    """
    通用外骨骼多任务模型：
    - 共享 Inception 骨干
    - 双任务头：意图分类 + 轨迹预测
    """
    def __init__(self, 
                 input_channels=39,
                 seq_len=50,
                 num_intents=5,
                 traj_dim=72,
                 hidden_dim=256):
        super(UniversalExoNet, self).__init__()
        self.backbone = InceptionBackbone(
            input_channels=input_channels,
            seq_len=seq_len,
            hidden_dim=hidden_dim
        )
        
        # 分类头
        self.intent_head = nn.SequentialCell([
            nn.Dense(hidden_dim, 128),
            nn.ReLU(),
            # 替换原来的 Dropout 行
            nn.Dropout(p=0.5),   # 丢弃 50%
            nn.Dense(128, num_intents)
        ])
        
        # 轨迹回归头
        self.traj_head = nn.SequentialCell([
            nn.Dense(hidden_dim, 256),
            nn.ReLU(),
            nn.Dropout(p=0.3),
            nn.Dense(256, traj_dim)
        ])

    def construct(self, x):
        """
        Args:
            x: (B, T, C) - e.g., (32, 50, 39)
        Returns:
            cls_out: (B, num_intents)
            traj_out: (B, traj_dim)
        """
        feat = self.backbone(x)  # (B, hidden_dim)
        cls_out = self.intent_head(feat)
        traj_out = self.traj_head(feat)
        return cls_out, traj_out


# ======================
# 使用示例（可删除）
# ======================
if __name__ == "__main__":
    import numpy as np
    from mindspore import Tensor
    
    # 模拟输入
    B, T, C = 4, 50, 39
    x = Tensor(np.random.randn(B, T, C).astype(np.float32))
    
    model = UniversalExoNet(
        input_channels=C,
        seq_len=T,
        num_intents=5,
        traj_dim=72
    )
    
    cls_out, traj_out = model(x)
    print("Classification output shape:", cls_out.shape)   # (4, 5)
    print("Trajectory output shape:", traj_out.shape)     # (4, 72)